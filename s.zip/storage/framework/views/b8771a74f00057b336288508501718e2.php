<!DOCTYPE html>
<html lang="en" class="dark scroll-smooth">
<?php
    $appName = config('app.name', 'Portfolio');
    $metaTitle = $meta['title'] ?? $appName;
    $metaDescription = $meta['description'] ?? 'Senior Software Developer — Laravel, Vue 3, and scalable web platforms. Selected case studies and contact.';
    $metaImage = $meta['image'] ?? null;
    $metaUrl = $meta['url'] ?? url()->current();
    $metaType = $meta['type'] ?? 'website';
?>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e($metaTitle); ?></title>
    <meta name="description" content="<?php echo e($metaDescription); ?>">
    <link rel="canonical" href="<?php echo e($metaUrl); ?>">

    
    <link rel="icon" href="<?php echo e(asset('favicon.svg')); ?>" type="image/svg+xml">
    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>" sizes="any">
    <link rel="apple-touch-icon" href="<?php echo e(asset('apple-touch-icon.png')); ?>">
    <meta name="theme-color" content="#070a12">

    
    <meta property="og:type" content="<?php echo e($metaType); ?>">
    <meta property="og:site_name" content="<?php echo e($appName); ?>">
    <meta property="og:title" content="<?php echo e($metaTitle); ?>">
    <meta property="og:description" content="<?php echo e($metaDescription); ?>">
    <meta property="og:url" content="<?php echo e($metaUrl); ?>">
    <?php if($metaImage): ?>
        <meta property="og:image" content="<?php echo e($metaImage); ?>">
        <meta property="og:image:width" content="1200">
        <meta property="og:image:height" content="630">
    <?php endif; ?>

    
    <meta name="twitter:card" content="<?php echo e($metaImage ? 'summary_large_image' : 'summary'); ?>">
    <meta name="twitter:title" content="<?php echo e($metaTitle); ?>">
    <meta name="twitter:description" content="<?php echo e($metaDescription); ?>">
    <?php if($metaImage): ?>
        <meta name="twitter:image" content="<?php echo e($metaImage); ?>">
    <?php endif; ?>

    
    <?php if(isset($profile)): ?>
        <script type="application/ld+json">
            <?php
                $sameAs = array_values(array_filter([
                    $profile->github_url,
                    $profile->linkedin_url,
                    $profile->twitter_url,
                    $profile->website_url,
                ]));
                $person = array_filter([
                    '@context' => 'https://schema.org',
                    '@type' => 'Person',
                    'name' => $profile->name,
                    'jobTitle' => $profile->title,
                    'description' => $metaDescription,
                    'email' => $profile->email,
                    'url' => url('/'),
                    'image' => $metaImage,
                    'address' => $profile->location,
                    'sameAs' => $sameAs ?: null,
                ], fn ($value) => ! is_null($value) && $value !== '' && $value !== []);
            ?>
            <?php echo json_encode($person, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>

        </script>
    <?php endif; ?>

    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=inter:400,500,600,700,800|jetbrains-mono:400,500" rel="stylesheet">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.ts']); ?>
</head>
<body class="bg-base-950 text-slate-200 antialiased">
    <div id="app"></div>
</body>
</html>
<?php /**PATH /media/salah/Software/projects/portfolio/resources/views/app.blade.php ENDPATH**/ ?>